

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


@WebServlet("/Search-By-Name")
public class SearchByName extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
		 String pName= request.getParameter("pName"); 
//		 int id=Integer.parseInt(pid);
		 
	 Connection con=null;
	 con= Final.getDBConnection();
	 PreparedStatement psmt=null;
	 ResultSet rs=null; 
	 
	 try {
		 
		psmt=con.prepareStatement("select * from products where product_name=? ");
		psmt.setString(1, pName);
		rs=psmt.executeQuery();
		 out.print("<html>"
			 		+ "<body>"						
			 		+ "<table>"
			 		+ "  <caption>Total products </caption>\r\n"
			 		+ "  <thead>\r\n"
			 		+ "      <tr>\r\n"
			 	    + "      <th>Product id</th>\r\n"
			 	    + "      <th>Product name</th>\r\n"
			 	    + "      <th>Product price</th>\r\n"
			        + "      <th>Product quantity</th>\r\n"
			        + "    </tr>\r\n"
			        + "  </thead>"
			        + " <tbody>"
            		);
		if(rs.next()) {
			Integer id1=rs.getInt(1);  
			String id2= String.valueOf(id1); 
        	request.setAttribute("pid", id2);
			String name=rs.getString(2);
			request.setAttribute("pname", name);
			Integer price=rs.getInt(3);
			String price2=String.valueOf(price);
        	request.setAttribute("pprice", price2); 
			Integer quantity=rs.getInt(4);
			String quantity2=String.valueOf(quantity);
        	request.setAttribute("pquantity", quantity2);

        	String producId = (String) request.getAttribute("pid") ;
            String productName = (String) request.getAttribute("pname");
            String productPrice = (String) request.getAttribute("pprice");
            String productQuantity = (String) request.getAttribute("pquantity");
            
            out.print( "    <tr>\r\n"
            		+ "      <td>"+producId+"</td>\r\n"
            		+ "      <td>"+productName+"</td>\r\n"
            	    + "      <td>"+productPrice+"</td>\r\n"
            	    + "      <td>"+productQuantity+"</td>\r\n"
            		+ "    </tr>\r\n"
            		); 
			}
		
		else {
			out.print("<h1>Product is not Available</h1>");
						}
		 
		out.print("</tbody>"
				+ "</tabld>"
				+ "</body>"
				+ "</html>"
				);	
		
	} catch (SQLException e) {
		
		e.printStackTrace();
	}finally { 
		try {
			 if(rs!=null) {
                    rs.close();
			  }else if(con!=null) { 
						con.close();
			   }
		   } catch (SQLException e) {
				e.printStackTrace();
				}
		}		
	
		
		
	}

}
