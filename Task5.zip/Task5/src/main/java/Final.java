

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


@WebServlet("/Final")
public class Final extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
		
		 
    	 String choice1 =  request.getParameter("choice").trim();
    	 
    	
		 int ch =Integer.parseInt(choice1);
		
		
		 System.out.println(ch);
    	
		switch(ch) { 
			  
		case 1:	 		
			 out.print("<html>");
			
			 
			 
			 
			 
			 
	            out.print("<body>"); 			
		     	out.print("<form action='Search-By-Id'method='POST'>");
		    	out.print("<h2>");
		     	out.print("Enter Product Id : <input type='text' name='pId'>");
		     	out.print("</br></br>");
		    	out.print("<button type='submit'>Next</button>");
		    	out.print("</h2>");
		    	out.print("</form>"); 
		    	out.print("</body>");
		     	out.print("</html>");
			
			
		 break;
		 
		case 2:
			 out.print("<html>");			  
	            out.print("<body>"); 			
		     	out.print("<form action='Search-By-Name'method='POST'>");
		    	out.print("<h2>");
		     	out.print("Enter Product Name : <input type='text' name='pName'>");
		     	out.print("</br></br>");
		    	out.print("<button type='submit'>Next</button>");
		    	out.print("</h2>");
		    	out.print("</form>"); 
		    	out.print("</body>");
		     	out.print("</html>");
			
			 break;
		 
		case 3:
			  
			 Connection con2=null;
			 con2=Final.getDBConnection();
			 PreparedStatement psmt2=null;
			 ResultSet rs2=null; 
			
			 try {
				psmt2=con2.prepareStatement("select * from products");
				rs2=psmt2.executeQuery();
				 out.print("<html>"
				 		            + "<head>"					 
							 		+ "  <meta charset=\"utf-8\">\r\n"
							 		+ "  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n"
							 		+ "  <link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css\">\r\n"
							 		+ "  <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js\"></script>\r\n"
							 		+ "  <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js\"></script>\r\n"
							 		+ "</head>"
				 		+ "<body>"
				 		+ "<div class=\"container\">\r\n"
				 		 		
				 		+ "  <table class=\"table table-bordered\">"
				 		+ "<center>"				 	
				 		+ "  <caption>Total products </caption>\r\n"
				 		+ "</center>"
				 		+ "  <thead>\r\n"
				 		+ "      <tr>\r\n"
				 	    + "      <th>Product id</th>\r\n"
				 	    + "      <th>Product name</th>\r\n"
				 	    + "      <th>Product price</th>\r\n"
				        + "      <th>Product quantity</th>\r\n"
				        + "    </tr>\r\n"
				        + "  </thead>"
				        + " <tbody>"
	            		);
				
				 
				
				
				while(rs2.next()) { 
					Integer id1=rs2.getInt(1);  
					String id2= String.valueOf(id1); 
		        	request.setAttribute("pid", id2);
					String name=rs2.getString(2);
					request.setAttribute("pname", name);
					Integer price=rs2.getInt(3);
					String price2=String.valueOf(price);
		        	request.setAttribute("pprice", price2); 
					Integer quantity=rs2.getInt(4);
					String quantity2=String.valueOf(quantity);
		        	request.setAttribute("pquantity", quantity2);
		
		        	String producId = (String) request.getAttribute("pid") ;
		            String productName = (String) request.getAttribute("pname");
		            String productPrice = (String) request.getAttribute("pprice");
		            String productQuantity = (String) request.getAttribute("pquantity");
		            
		            out.print( "    <tr>\r\n"
		            		+ "      <td>"+producId+"</td>\r\n"
		            		+ "      <td>"+productName+"</td>\r\n"
		            	    + "      <td>"+productPrice+"</td>\r\n"
		            	    + "      <td>"+productQuantity+"</td>\r\n"
		            		+ "    </tr>\r\n"
		            		); 
		           
//		            out.print("<h3>"+producId+"  " +productName +" "+"  "+productPrice +"  "+productQuantity+"  "+"</h3>");
		            
								}
				
				out.print("</tbody>"
						+ "</tabld>"
						+ "</body>"
						+ "</html>"
						);				
				}  
			 catch (SQLException e) {
				
				e.printStackTrace();
			} finally { 
				try {
					 if(rs2!=null) {
		                     rs2.close();
					  }else if(con2!=null) { 
								con2.close();
					   }
				   } catch (SQLException e) {
						e.printStackTrace();
						}
				}		
			 
			
			 break;
		}
			
		 
		 
		 }
	
	
			
			 
		 
		
		
	
	
	
	public static Connection getDBConnection() 
	{ 
Connection con=null; 
	try { 
Class.forName("com.mysql.cj.jdbc.Driver"); /*Driver Registration   */
con=DriverManager.getConnection("jdbc:mysql://localhost:3306/productdb?useSSL=false","root","300805");/* Create connection*/
	} catch(ClassNotFoundException e) {
		e.printStackTrace();
	} catch(SQLException e) {
			e.printStackTrace();
		}
return con;
} 

}
