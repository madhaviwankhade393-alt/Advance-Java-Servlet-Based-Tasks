

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException; 
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/jdbc-Servlet")
public class jdbcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
		 
		 
		 String uchoice= request.getParameter("choice");		
		 int ch =Integer.parseInt(uchoice);		 
		 switch(ch) {
		 case 1:
			
			 request.setAttribute("choice", ch);
	 
			   RequestDispatcher dis = request.getRequestDispatcher("Final");
			   dis.forward(request, response);
			
			 break;
			 
		 case 2:
			
			 request.setAttribute("choice", ch);
			 out.print("Enter Product Name : <input type='text' name='pName'>");
			 RequestDispatcher dis2 = request.getRequestDispatcher("Final");
			   dis2.forward(request, response);
			 break;
			  
		 case 3:
			 request.setAttribute("choice", ch);
			 RequestDispatcher dis3 = request.getRequestDispatcher("Final");
			 dis3.forward(request, response);
			 break;
			 
			default:
				out.print(" <h2>Invalid choice</h2>");
				break;
			
		 }
		 
		
		
		
	}
	
	

}
