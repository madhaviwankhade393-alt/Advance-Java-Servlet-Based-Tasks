

import jakarta.servlet.ServletException; 
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

@WebServlet("/Jdbc-Servlet")
public class JdbcServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 response.setContentType("text/html");
		 PrintWriter out = response.getWriter();
	   	 String productId= request.getParameter("pid").trim();
	   	 int pId=Integer.parseInt(productId);
	     String productName = request.getParameter("pname").trim(); 
	     String productPrice = request.getParameter("pprice").trim();
	     String productQuantity = request.getParameter("pquantity").trim();
			int productQ= Integer.parseInt(productQuantity);
			int count=0;
			 Connection con=null;
	    	try { 
	    Class.forName("com.mysql.cj.jdbc.Driver"); /*Driver Registration   */
	    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/productdb?useSSL=false","root","300805");/* Create connection*/
	    PreparedStatement psmt=null; 
	    psmt=con.prepareStatement("insert into products(product_id,product_name,product_price,product_quantity)values(?,?,?,?)");
	    psmt.setInt(1,pId);
	    psmt.setString(2,productName );
		psmt.setString(3, productPrice);
		psmt.setInt(4,productQ);
		count=psmt.executeUpdate(); 
	    	} catch(ClassNotFoundException e) {
	    		e.printStackTrace();
	    	} catch(SQLException e) {
	    			e.printStackTrace();
	    		}finally {
	    			
	    			try {
	    				if(con!=null)
	    				{

	    				con.close();
	    				}
	    			} catch (SQLException e) {
	    				e.printStackTrace();
	    			}
	    		}
		
	    	if(count>0) {
	         out.print("<h1>Procuct inserted Successfully</h1>");
	    	}
	    	else {
	    		out.print("<h1>Procuct insertion failed</h1>");
	    	}
	}

}
