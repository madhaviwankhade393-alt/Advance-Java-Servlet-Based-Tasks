

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/Product")
public class Product extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        out.print("<html>");
	        out.print("<head>");
	          
	        out.print("</head>");
	        out.print("<body>");
	            out.print("<center>");
	            out.print("<h1> Product Registration </h1>");
	            out.print("<h3>");
	                 out.print("<form action='Jdbc-Servlet' method='POST'>");
	                 out.print("Enter Product Id : <input type='text' name='pid'>");
	                    out.print("</br></br>");
	                    out.print("Enter Product Name : <input type='text' name='pname'>");
	                    out.print("</br></br>");
	                    out.print("Enter Product Price : <input type='text' name='pprice'>");
	                    out.print("</br></br>");
	                    out.print("Enter Product Quantity : <input type='text' name='pquantity'>");
	                    out.print("</br></br>");
	                    out.print("<button type='submit'>Submit</button>");
	                out.print("</form>");
	                out.print("</h3>");
	            out.print("</center>");
	        out.print("</body>");
	        out.print("</html>");
	}

}
