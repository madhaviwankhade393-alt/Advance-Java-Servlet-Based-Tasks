

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/Display")
public class Display extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String name = request.getParameter("name");
		String gen=request.getParameter("gender");
		String ct =request.getParameter("Contact"); 
		String prefix ="Male".equalsIgnoreCase(gen) ? "Mr. " : "Ms. ";  		
		out.print("<h1> Welcome User  </h1>");
		out.print("<h3> "+prefix + name +"</h3>");
		out.print("<h3>Contact :"+ ct+"</h3>"); 
	}

}

