

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/UserDetails")
public class UserDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out =response.getWriter();
		out.print("<html>");
		    out.print("<head>");
		        out.print("<title>User Detailes</title>"); 
		out.print("</head>");
		out.print("<body>"); 
		
	     	out.print("<form action='Display'method='POST'>");
	    	out.print("Enter Name: <input type='text' name='name'>");
	    	out.print("<br/><br/>");
	    	out.print("Select Gender : <input type='radio' name='gender' value='Male'>Male");
	    	out.print(" <input type='radio' name='gender' value='Female'>Female");
	    	out.print("<br/><br/>");
	    	out.print("Enter Contact : <input type='number' name='Contact'>");
	    	out.print("<br/><br/>");
	    	out.print("Enter Password: <input type='password' name='Userpass'>");
	    	out.print("<button type='submit'>Send</button>");
	    	out.print("</form>"); 
	    	out.print("</body>");
	     	out.print("</html>");
	}

}
