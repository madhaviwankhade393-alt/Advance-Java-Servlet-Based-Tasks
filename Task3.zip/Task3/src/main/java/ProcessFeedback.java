

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/Process-Feedback")
public class ProcessFeedback extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
        response.setContentType("text/html");
    	String userName = request.getParameter("uname").trim(); 
        String userRating = request.getParameter("urating").trim();
        int rating=Integer.parseInt(userRating);
        PrintWriter out = response.getWriter();
        out.print("<h1>This is Feedback processing page</h1>");
        if(rating==5) {
        	String points="1000";
        	request.setAttribute("upoints", points);
        	  RequestDispatcher dis = request.getRequestDispatcher("Thank-You-Page");
        	  dis.forward(request, response);
      	 
        }
        else if(rating==3 ||rating==4) {
        	String points="500";
        	request.setAttribute("upoints", points);
        	 RequestDispatcher dis = request.getRequestDispatcher("Thank-You-Page");
        	 dis.forward(request, response);
        	
        }
        else {
        	String points="100";
        	request.setAttribute("upoints", points);
        	 RequestDispatcher dis = request.getRequestDispatcher("Thank-You-Page");
        	 dis.forward(request, response);
        }
        
	}

}
