

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/Login-Page")
public class LoginPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		  response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        out.print("<html>");
	        out.print("<head>");
	            out.print("<title>User Login Page</title>");
	        out.print("</head>");
	        out.print("<body>");
	            out.print("<center>");
	                out.print("<h3>User Login</h3>");
	                 out.print("<form action='User-Authentication-Page' method='POST'>");
	                    out.print("Enter User Name : <input type='text' name='uname'>");
	                    out.print("</br></br>");
	                    out.print("Enter Password : <input type='password' name='upass'>");
	                    out.print("</br></br>");
	                    out.print("<button type='submit'>Login</button>");
	                out.print("</form>");
	            out.print("</center>");
	        out.print("</body>");
	        out.print("</html>");
		
		
	}

}
