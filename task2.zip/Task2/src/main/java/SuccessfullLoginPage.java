

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/Successfull-Login-Page")
public class SuccessfullLoginPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		  response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        out.print("<h1>Welcome User to Home.</h1>");
	        String userName = request.getParameter("uname").trim();
	        String email = (String) request.getAttribute("uemail");
	        out.print("<h3>User : "+userName+"</h3>");
	        out.print("<h3>Email : "+email+"</h3>");
		
		
		
	}

}
