

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


@WebServlet("/User-Authentication-Page")
public class UserAuthenticationPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		  String userName = request.getParameter("uname").trim();
	        String userPassword = request.getParameter("upass").trim();
	        response.setContentType("text/html");
	        PrintWriter out = response.getWriter();
	        out.print("<h1>This is Validate Page</h1>"); 
 
	        if("Madhavi".equals(userName) && "madhu@123".equals(userPassword)) {
	            String email = "madhavi3008@gmail.com";
	            request.setAttribute("uemail", email);
	            RequestDispatcher dis = request.getRequestDispatcher("Successfull-Login-Page");
	            //dis.include(req, resp);
	            dis.forward(request, response);
	        } else {
	            response.sendRedirect("Login-Failur-Page");
	            //resp.sendRedirect("https://www.google.com/search?q=java");
		
	}

} 
}
